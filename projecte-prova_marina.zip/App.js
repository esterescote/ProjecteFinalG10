import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function App() {
  console.log("App loaded!");
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Hola! Això funciona 🎉</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#222',
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: 'white',
    fontSize: 20,
  },
});
