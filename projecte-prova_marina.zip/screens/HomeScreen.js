import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';

const HomeScreen = ({ navigation }) => 
{
console.log("HomeScreen loaded!");
  return (
    <View style={styles.container}>
      <Text style={styles.greeting}>Nice to see you here again!</Text>

      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('NewChallenges')} >
          <Text style={styles.cardText}>Start taking challenges or create your own</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('MyChallenges')}>
          <Text style={styles.cardText}>Check the state of your current challenge</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Progress')}>
          <Text style={styles.cardText}>Your progress, points, challenges completed...</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2E1F1F',
    padding: 20,
    paddingTop: 60,
  },
  greeting: {
    fontSize: 24,
    color: 'white',
    marginBottom: 20,
    fontWeight: 'bold',
  },
  card: { backgroundColor: "#3E2E2E", borderRadius: 10, marginBottom: 15, padding: 15 },

  cardText: {
    color: 'white',
    fontSize: 16,
    padding: 10,
    backgroundColor: 'rgba(0,0,0,0.4)',
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
  },
});
export default HomeScreen;
